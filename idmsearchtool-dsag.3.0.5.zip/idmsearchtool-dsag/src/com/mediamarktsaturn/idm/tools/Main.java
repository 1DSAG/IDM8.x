// ********************************************************************************
// IdM Search Tool (only IdM 8 @Oracle is supported)
// Version for DSAG members only
// ********************************************************************************// 
// **** Legal Disclaimer ***
// The IdM Search Tool is provided by Andreas Zickner "as is" and "with all faults." 
// Andreas Zickner makes no representations or warranties of any kind concerning the 
// safety, suitability, lack of viruses, inaccuracies, typographical errors, or other 
// harmful components of the IdM Search Tool. There are inherent dangers in the use 
// of any software, and you are solely responsible for determining whether the IdM 
// Search Tool is compatible with your equipment and other software installed on your 
// equipment. You are also solely responsible for the protection of your equipment 
// and backup of your data, and Andreas Zickner will not be liable for any damages 
// you may suffer in connection with using, modifying, or distributing the IdM Search Tool.
// ********************************************************************************

package com.mediamarktsaturn.idm.tools;

import java.util.Map;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.fxml.FXMLLoader;

public class Main extends Application
{

   public static Map<String, String> commandLineParameters;

   @Override
   public void start(Stage primaryStage)
   {
      try {
         commandLineParameters = getParameters().getNamed();
         BorderPane root = (BorderPane) FXMLLoader.load(getClass().getResource("mainpane.fxml"));
         Scene scene = new Scene(root); // , 600, 480
         scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
         primaryStage.setScene(scene);
         primaryStage.setTitle("IdM Source Code Viewer");
         primaryStage.show();
      } catch (Exception e) {
         e.printStackTrace();
      }
   }

   public static void main(String[] args)
   {
      //  --debugjobguids=196731BA-4885-4FB6-B696-AD31DC248D2F,FB179883-9921-4059-A857-D91DA9EF7C37,44F9AB48-26DB-45C9-AC18-155D856E0BB4
      System.out.println("Info: Use the following commandline to start IdM Source Code Viewer:");
      System.out.println(
            "  java -jar idmviewer.jar --hostname=localhost --username=mxmc_oper --password=geheim --driver=jdbc:oracle:thin: --class=oracle.jdbc.driver.OracleDriver --port=1522 --sid=IDM");
      launch(args);
   }

}
