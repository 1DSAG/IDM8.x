// ********************************************************************************
// IdM Search Tool (only IdM 8 @Oracle is supported)
// Version for DSAG members only
// ********************************************************************************// 
// **** Legal Disclaimer ***
// The IdM Search Tool is provided by Andreas Zickner "as is" and "with all faults." 
// Andreas Zickner makes no representations or warranties of any kind concerning the 
// safety, suitability, lack of viruses, inaccuracies, typographical errors, or other 
// harmful components of the IdM Search Tool. There are inherent dangers in the use 
// of any software, and you are solely responsible for determining whether the IdM 
// Search Tool is compatible with your equipment and other software installed on your 
// equipment. You are also solely responsible for the protection of your equipment 
// and backup of your data, and Andreas Zickner will not be liable for any damages 
// you may suffer in connection with using, modifying, or distributing the IdM Search Tool.
// ********************************************************************************

package com.mediamarktsaturn.idm.tools;



import java.io.UnsupportedEncodingException;


public class Base64
{

 public Base64()
 {
 }

 public static String encode(String aIn)
 {
     byte bb[] = new byte[0];
     try
     {
         bb = aIn.getBytes("UTF-8");
     }
     catch(UnsupportedEncodingException e) { }
     return "{B64}" + encode(bb, true);
 }

 public static String encode(byte aIn[])
 {
     return encode(aIn, false);
 }

 public static String encode(byte aIn[], boolean aEqualsPad)
 {
     char out[] = new char[((aIn.length + 2) / 3) * 4];
     int rem = aIn.length % 3;
     int o = 0;
     for(int i = 0; i < aIn.length;)
     {
         int val = (aIn[i++] & 0xff) << 16;
         if(i < aIn.length)
             val |= (aIn[i++] & 0xff) << 8;
         if(i < aIn.length)
             val |= aIn[i++] & 0xff;
         out[o++] = sBase64Alphabet[val >> 18 & 0x3f];
         out[o++] = sBase64Alphabet[val >> 12 & 0x3f];
         out[o++] = sBase64Alphabet[val >> 6 & 0x3f];
         out[o++] = sBase64Alphabet[val & 0x3f];
     }

     int outLen = out.length;
     switch(rem)
     {
     case 1: // '\001'
         outLen -= 2;
         break;

     case 2: // '\002'
         outLen--;
         break;

     default:
         outLen = out.length;
         break;
     }
     if(aEqualsPad)
         while(outLen < out.length) 
             out[outLen++] = '=';
     return new String(out, 0, outLen);
 }

 public static byte[] decode(String aInStr)
     throws IllegalBase64Exception
 {
     byte out[];
     if(aInStr.substring(0, 5).equalsIgnoreCase("{b64}"))
         aInStr = aInStr.substring(5);
     else
     if(aInStr.substring(0, 8).equalsIgnoreCase("{base64}"))
         aInStr = aInStr.substring(8);
     byte in[];
     try
     {
         in = aInStr.getBytes("US-ASCII");
     }
     catch(UnsupportedEncodingException uee)
     {
         throw new IllegalBase64Exception("Could not convert base64 encoded data using US_ASCII encoding");
     }
     int inLength;
     for(inLength = in.length; inLength > 0 && in[inLength - 1] == 61; inLength--);
     int blocks = inLength / 4;
     int remainder = inLength & 3;
     int wholeInLen = blocks * 4;
     int wholeOutLen = blocks * 3;
     int outLen = wholeOutLen;
     switch(remainder)
     {
     case 1: // '\001'
         throw new IllegalBase64Exception("illegal Base64 length");

     case 2: // '\002'
         outLen = wholeOutLen + 1;
         break;

     case 3: // '\003'
         outLen = wholeOutLen + 2;
         break;

     default:
         outLen = wholeOutLen;
         break;
     }
     out = new byte[outLen];
     int o = 0;
     int i;
     for(i = 0; i < wholeInLen;)
     {
         int in1 = sBase64Reverse[in[i]];
         int in2 = sBase64Reverse[in[i + 1]];
         int in3 = sBase64Reverse[in[i + 2]];
         int in4 = sBase64Reverse[in[i + 3]];
         int orValue = in1 | in2 | in3 | in4;
         if((orValue & 0x80) != 0)
             throw new IllegalBase64Exception("illegal Base64 characters:" + in[i] + in[i + 1] + in[i + 2] + in[i + 3]);
         int outVal = in1 << 18 | in2 << 12 | in3 << 6 | in4;
         out[o] = (byte)(outVal >> 16);
         out[o + 1] = (byte)(outVal >> 8);
         out[o + 2] = (byte)outVal;
         i += 4;
         o += 3;
     }

     int orValue;
     switch(remainder)
     {
     case 2: // '\002'
     {
         int in1 = sBase64Reverse[in[i]];
         int in2 = sBase64Reverse[in[i + 1]];
         orValue = in1 | in2;
         int outVal = in1 << 18 | in2 << 12;
         out[o] = (byte)(outVal >> 16);
         break;
     }

     case 3: // '\003'
     {
         int in1 = sBase64Reverse[in[i]];
         int in2 = sBase64Reverse[in[i + 1]];
         int in3 = sBase64Reverse[in[i + 2]];
         orValue = in1 | in2 | in3;
         int outVal = in1 << 18 | in2 << 12 | in3 << 6;
         out[o] = (byte)(outVal >> 16);
         out[o + 1] = (byte)(outVal >> 8);
         break;
     }

     default:
     {
         orValue = 0;
         break;
     }
     }
     if((orValue & 0x80) != 0)
         throw new IllegalBase64Exception("illegal Base64 character");
     
     return out;
 }

 private static char sBase64Alphabet[] = {
     'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 
     'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 
     'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 
     'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 
     'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 
     'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', 
     '8', '9', '+', '/'
 };
 private static byte sBase64Reverse[];

 static 
 {
     sBase64Reverse = new byte[128];
     for(int i = 0; i < sBase64Reverse.length; i++)
         sBase64Reverse[i] = -1;

     for(int i = 0; i < sBase64Alphabet.length; i++)
         sBase64Reverse[sBase64Alphabet[i]] = (byte)i;

 }
}
