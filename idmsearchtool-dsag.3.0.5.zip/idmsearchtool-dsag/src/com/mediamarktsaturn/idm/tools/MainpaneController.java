// ********************************************************************************
// IdM Search Tool (only IdM 8 @Oracle is supported)
// Version for DSAG members only
// ********************************************************************************// 
// **** Legal Disclaimer ***
// The IdM Search Tool is provided by Andreas Zickner "as is" and "with all faults." 
// Andreas Zickner makes no representations or warranties of any kind concerning the 
// safety, suitability, lack of viruses, inaccuracies, typographical errors, or other 
// harmful components of the IdM Search Tool. There are inherent dangers in the use 
// of any software, and you are solely responsible for determining whether the IdM 
// Search Tool is compatible with your equipment and other software installed on your 
// equipment. You are also solely responsible for the protection of your equipment 
// and backup of your data, and Andreas Zickner will not be liable for any damages 
// you may suffer in connection with using, modifying, or distributing the IdM Search Tool.
// ********************************************************************************

package com.mediamarktsaturn.idm.tools;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import goryachev.fx.CPane;
import goryachev.fx.CssStyle;
import goryachev.fx.FX;
import goryachev.fx.edit.FxEditor;
import goryachev.fx.edit.SimpleStyledTextModel;
import goryachev.fx.edit.TStyle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

public class MainpaneController
{
   // --debugjobguids=53FAEE30-830D-44E0-9278-E2AD417C7564
   private static String S_version = "v3.0.5 for 80";
   private Search idmSearch = null;

   @FXML
   private TextField searchText;
   @FXML
   private Button searchButton;
   @FXML
   private TreeView<com.mediamarktsaturn.idm.tools.Element> resultTree;
   @FXML
   private Pane resultPane;
   @FXML
   private VBox resultBox;
   @FXML
   private CheckBox expandTree;
   @FXML
   private TextFlow resultText;
   @FXML
   private Label statusBar;
   @FXML
   private CheckBox caseSensitiv;
   @FXML
   private CheckBox showXML;
   @FXML
   private Button reloadData;
   @FXML
   private Button copyData;
   @FXML
   private Button copyId;
   @FXML
   private TextField connectDBHostname;
   @FXML
   private TextField connectDBPort;
   @FXML
   private TextField connectDBSID;
   @FXML
   private TextField connectDBusername;
   @FXML
   private TextField connectDBpassword;
   @FXML
   private TextField infoBox;

   private boolean dataLoaded = false;

   private final Image icFolderIcon = new Image(getClass().getResourceAsStream("img/ic.png"));
   private final Image taskFolderIcon = new Image(getClass().getResourceAsStream("img/task-folder.png"));
   private final Image jobFolderIcon = new Image(getClass().getResourceAsStream("img/job-folder.png"));
   private final Image folderIcon = new Image(getClass().getResourceAsStream("img/folder.png"));
   private final Image scriptIcon = new Image(getClass().getResourceAsStream("img/javascript.png"));
   private final Image jobIcon = new Image(getClass().getResourceAsStream("img/job.png"));
   private final Image scriptFolderIcon = new Image(getClass().getResourceAsStream("img/javascript-folder.png"));
   private final Image constantIcon = new Image(getClass().getResourceAsStream("img/constant.png"));
   private final Image taskIcon = new Image(getClass().getResourceAsStream("img/task.png"));
   private final Image taskIconCondition = new Image(getClass().getResourceAsStream("img/task-conditional.png"));
   private final Image taskIconSwitch = new Image(getClass().getResourceAsStream("img/task-switch.png"));
   private final Image taskIconApproval = new Image(getClass().getResourceAsStream("img/task-approval.png"));
   private final Image taskIconJobTask = new Image(getClass().getResourceAsStream("img/task-action.png"));
   private final Image taskIconAttributes = new Image(getClass().getResourceAsStream("img/task-attributes.png"));
   private final Image taskIconAccessControls = new Image(getClass().getResourceAsStream("img/task-accesscontrol.png"));
   private final Image packageIcon = new Image(getClass().getResourceAsStream("img/package.png"));

   private Map<String, Image> pictures;
   private Map<String, TreeItem<com.mediamarktsaturn.idm.tools.Element>> anchors;
   private HashMap<String, String> packageNames = null;

   private com.mediamarktsaturn.idm.tools.Element currentSelectedElement;

   private String dbg_guids = null;
   private boolean checkIdM8 = false;
   private boolean checkGlobalConstants = false;
   private boolean checkScripts = false;
   private boolean autoCopyID = false;
   private boolean showAllwaysXML = true;

   public void initialize()
   {
      System.out.println("Initalize Called");
      parseArguments(Main.commandLineParameters);
      S_version += " Settings: autoCopyID:" + autoCopyID + " showXML:" + showAllwaysXML;
      pictures = new HashMap<String, Image>();
      pictures.put("FOLDER", folderIcon);
      pictures.put("JOBFOLDER", jobFolderIcon);
      pictures.put("TASKFOLDER", taskFolderIcon);
      pictures.put("SCRIPT", scriptIcon);
      pictures.put("CONSTANT", constantIcon);
      pictures.put("JOB", jobIcon);
      pictures.put("TASK", taskIcon);
      pictures.put("TASK:APPROVAL", taskIconApproval);
      pictures.put("TASK:SWITCH", taskIconSwitch);
      pictures.put("TASK:CONDITIONAL", taskIconCondition);
      pictures.put("TASK:JOBTASK", taskIconJobTask);
      pictures.put("TASKACCESS", taskIconAccessControls);
      pictures.put("TASKATTRIBUTE", taskIconAttributes);
      pictures.put("PACKAGE", packageIcon);
      currentSelectedElement = null;

      resultTree.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Object>() {

         @Override
         public void changed(ObservableValue<?> observable, Object oldValue, Object newValue)
         {

            @SuppressWarnings("unchecked")
            TreeItem<com.mediamarktsaturn.idm.tools.Element> selectedItem = (TreeItem<com.mediamarktsaturn.idm.tools.Element>) newValue;
            viewElementXML(observable, selectedItem);
         }

      });
      statusBar.setText("No Data loaded. " + S_version);
      showXML.setSelected(true);
   }

   @FXML
   private void startSearch()
   {
      loadIdMData();
      cleanTree();
      processData("Search");
   }

   @FXML
   private void reloadData()
   {
      dataLoaded = false;
      loadIdMData();
      cleanTree();
   }

   private void processData(String mode)
   {
      String S_search = searchText.getText();
      System.out.println("\r\nRunning in mode " + mode + " for: " + S_search);
      HashMap<String, TreeItem<com.mediamarktsaturn.idm.tools.Element>> allreadyLinked = new HashMap<String, TreeItem<com.mediamarktsaturn.idm.tools.Element>>();
      List<com.mediamarktsaturn.idm.tools.Element> foundData = null;
      try {
         if (mode.equalsIgnoreCase("SEARCH")) {
            foundData = idmSearch.findElements(S_search, caseSensitiv.isSelected());
         } else {
            foundData = idmSearch.findConfigInconsistency(S_search, this.checkIdM8, checkGlobalConstants, checkScripts);
         }
         for (com.mediamarktsaturn.idm.tools.Element found : foundData) {
            // System.out.println(found.toString());
            TreeItem<com.mediamarktsaturn.idm.tools.Element> foundTree = buildElementTree(allreadyLinked, found);
            if (foundTree != null) {
               addPackage(foundTree.getValue().getPackageName());
               TreeItem<com.mediamarktsaturn.idm.tools.Element> anchorTree = anchors.get(foundTree.getValue().getAchorType());
               if (anchorTree.getChildren().contains(foundTree) == false) {
                  anchorTree.setExpanded(false);
                  anchorTree.getChildren().add(foundTree);
               }
            }
         }
      } catch (Exception e) {
         System.out.println("processData exception: " + e.toString());
         e.printStackTrace();
      }
      System.out.println("Done.");
      statusBar.setText(mode + " finished. Found: " + foundData.size() + " " + S_version);
   }

   @FXML
   private void copyData()
   {
      if (currentSelectedElement != null && currentSelectedElement.getData() != null) {
         final Clipboard clipboard = Clipboard.getSystemClipboard();
         final ClipboardContent content = new ClipboardContent();
         content.putString(currentSelectedElement.getData());
         clipboard.setContent(content);
      }
   }

   @FXML
   private void copyId()
   {
      if (currentSelectedElement != null && currentSelectedElement.getElementId() != null) {
         final Clipboard clipboard = Clipboard.getSystemClipboard();
         final ClipboardContent content = new ClipboardContent();
         content.putString("" + currentSelectedElement.getId());
         clipboard.setContent(content);
      }
   }

   private void cleanTree()
   {
      currentSelectedElement = null;
      resultTree.setRoot(null);
      anchors = new HashMap<String, TreeItem<com.mediamarktsaturn.idm.tools.Element>>();
      com.mediamarktsaturn.idm.tools.Element menu = new com.mediamarktsaturn.idm.tools.Element("FOLDER", "IDM");
      TreeItem<com.mediamarktsaturn.idm.tools.Element> root = new TreeItem<com.mediamarktsaturn.idm.tools.Element>(menu, new ImageView(icFolderIcon));
      root.setExpanded(true);
      resultTree.setRoot(root);
      expandTree.setSelected(false);
   }

   @FXML
   private void chooseXML()
   {
      showAllwaysXML = showXML.isSelected();
   }

   @FXML
   private void expandColapse()
   {
      boolean expand = expandTree.isSelected();
      TreeItem<com.mediamarktsaturn.idm.tools.Element> root = resultTree.getRoot();
      _expandColapse(root, expand);
   }

   private void _expandColapse(TreeItem<com.mediamarktsaturn.idm.tools.Element> lroot, boolean expand)
   {
      if (lroot.isLeaf()) {
         return;
      }
      ObservableList<TreeItem<com.mediamarktsaturn.idm.tools.Element>> itemList = lroot.getChildren();
      if (itemList == null) {
         return;
      }
      for (TreeItem<com.mediamarktsaturn.idm.tools.Element> item : itemList) {
         if (item == null) {
            return;
         }
         item.setExpanded(expand);
         _expandColapse(item, expand);
      }
   }

   private void addPackage(String packageName)
   {
      TreeItem<com.mediamarktsaturn.idm.tools.Element> itemPackage;
      TreeItem<com.mediamarktsaturn.idm.tools.Element> itemScripts;
      TreeItem<com.mediamarktsaturn.idm.tools.Element> itemConstants;
      TreeItem<com.mediamarktsaturn.idm.tools.Element> itemTasks;
      TreeItem<com.mediamarktsaturn.idm.tools.Element> itemJobs;
      TreeItem<com.mediamarktsaturn.idm.tools.Element> root = resultTree.getRoot();

      if (anchors.get(packageName) != null) {
         return;
      }
      int packageID = Integer.parseInt(packageNames.get(packageName));
      com.mediamarktsaturn.idm.tools.Element menu = new com.mediamarktsaturn.idm.tools.Element("PACKAGE", packageName, packageID, 0, "", 0, null, null);
      itemPackage = new TreeItem<com.mediamarktsaturn.idm.tools.Element>(menu, new ImageView(packageIcon));
      itemPackage.setExpanded(false);
      root.getChildren().add(itemPackage);
      anchors.put(packageName, itemPackage);

      menu = new com.mediamarktsaturn.idm.tools.Element("FOLDER", "Scripts");
      itemScripts = new TreeItem<com.mediamarktsaturn.idm.tools.Element>(menu, new ImageView(scriptFolderIcon));
      itemScripts.setExpanded(false);
      itemPackage.getChildren().add(itemScripts);
      anchors.put(packageName + ".SCRIPT", itemScripts);

      menu = new com.mediamarktsaturn.idm.tools.Element("FOLDER", "Constants");
      itemConstants = new TreeItem<com.mediamarktsaturn.idm.tools.Element>(menu, new ImageView(constantIcon));
      itemConstants.setExpanded(false);
      itemPackage.getChildren().add(itemConstants);
      anchors.put(packageName + ".CONSTANT", itemConstants);

      menu = new com.mediamarktsaturn.idm.tools.Element("FOLDER", "Tasks");
      itemTasks = new TreeItem<com.mediamarktsaturn.idm.tools.Element>(menu, new ImageView(taskFolderIcon));
      itemTasks.setExpanded(false);
      itemPackage.getChildren().add(itemTasks);
      anchors.put(packageName + ".TASK", itemTasks);
      anchors.put(packageName + ".TASKFOLDER", itemTasks);

      menu = new com.mediamarktsaturn.idm.tools.Element("FOLDER", "Jobs");
      itemJobs = new TreeItem<com.mediamarktsaturn.idm.tools.Element>(menu, new ImageView(jobFolderIcon));
      itemJobs.setExpanded(false);
      itemPackage.getChildren().add(itemJobs);
      anchors.put(packageName + ".JOB", itemJobs);
      anchors.put(packageName + ".JOBFOLDER", itemJobs);
   }

   private TreeItem<com.mediamarktsaturn.idm.tools.Element> buildElementTree(HashMap<String, TreeItem<com.mediamarktsaturn.idm.tools.Element>> allreadyLinked,
         com.mediamarktsaturn.idm.tools.Element start)
   {
      com.mediamarktsaturn.idm.tools.Element actual = start;
      com.mediamarktsaturn.idm.tools.Element lastTop = null;
      TreeItem<com.mediamarktsaturn.idm.tools.Element> item = null;
      TreeItem<com.mediamarktsaturn.idm.tools.Element> childItem = null;

      try {
         if (allreadyLinked.get(actual.getGuid()) == null) {
            item = new TreeItem<com.mediamarktsaturn.idm.tools.Element>(actual, new ImageView(pictures.get(actual.getType())));
            item.setExpanded(false);
            allreadyLinked.put(actual.getGuid(), item);
            childItem = item;
         } else {
            childItem = allreadyLinked.get(actual.getGuid());
         }
         lastTop = actual.getParent();

         while ((actual = actual.getParent()) != null) {
            if ((item = allreadyLinked.get(actual.getGuid())) == null) {
               item = new TreeItem<com.mediamarktsaturn.idm.tools.Element>(actual, new ImageView(pictures.get(actual.getType())));
               item.setExpanded(false);
               item.getChildren().add(childItem);
               allreadyLinked.put(actual.getGuid(), item);
            } else {
               // link child if not done so far
               if ((item != childItem) && (item.getChildren().contains(childItem) == false)) {
                  item.getChildren().add(childItem);
               }
            }
            childItem = item;
            lastTop = actual.getParent();
         }
         // link in the top to a potential existing
         if (lastTop != null && ((item = allreadyLinked.get(lastTop.getGuid())) != null)) {
            if ((item != childItem) && (item.getChildren().contains(childItem) == false)) {
               item.getChildren().add(childItem);
            }
            return null; // as this is linked on a lower level ... don't link it
                         // on top level
         }
      } catch (Exception e) {
         System.out.println("buildElementTree exception: " + e.toString());
         e.printStackTrace();
      }
      return item;
   }

   public static CssStyle EDITOR = new CssStyle("FxEditorStyledModelXMLPane");
   public SimpleStyledTextModel model = null;

   
   private ArrayList<Object> addAttributeValue(Color color, ArrayList<Object> fullTextObject, String attrname, String value)
   {
      return (addAttributeValue(color, fullTextObject, attrname, value, null));
   }

   private ArrayList<Object> addAttributeValue(Color color, ArrayList<Object> fullTextObject, String attrname, String value, String redString)
   {
      return(addAttributeValue(color, fullTextObject, attrname, value, redString, Color.BLACK));
   }
   
   private ArrayList<Object> addAttributeValue(Color color, ArrayList<Object> fullTextObject, String attrname, String value, String redString, Color colorValue)
   {
      String attrnameFull = String.format("%-12s\t", attrname) + " ";
      if (redString == null) {
         fullTextObject.add(new TStyle().foreground(color));
         fullTextObject.add(attrnameFull);
         fullTextObject.add(null);
         fullTextObject.add(value + "\n");
      } else {
         fullTextObject = getColorSelectedString(color, fullTextObject, attrnameFull, redString);
         fullTextObject = getColorSelectedString(colorValue, fullTextObject, value + "\n", redString);
      }
      return (fullTextObject);
   }

   private ArrayList<Object> getColorSelectedString(ArrayList<Object> fullTextObject, String data, String S_search)
   {
      return (getColorSelectedString(null, fullTextObject, data, S_search));
   }

   private ArrayList<Object> getColorSelectedString(Color color, ArrayList<Object> fullTextObject, String data, String S_search)
   {
      String literalSearch;
      String modified;
      if (caseSensitiv.isSelected()) {
         literalSearch = Pattern.quote(S_search);
         modified = data;
      } else {
         literalSearch = Pattern.quote(S_search.toUpperCase());
         modified = new String(data.replaceAll("(?i)"+Pattern.quote(S_search.toLowerCase()), Matcher.quoteReplacement(S_search.toUpperCase())));
      }
      String[] parts = modified.split(literalSearch);
      for (int i = 0; i < parts.length; i++) {
         if (parts[i].length() > 0) {
            if (color != null) {
               fullTextObject.add(new TStyle().foreground(color));
            } else {
               fullTextObject.add(null);
            }
            fullTextObject.add(parts[i]);
         }
         if (i + 1 < parts.length) {
            fullTextObject.add(new TStyle().foreground(Color.RED));
            fullTextObject.add(S_search);
         }
      }
      return (fullTextObject);
   }

   @SuppressWarnings("unchecked")
   private void viewElementXML(ObservableValue<?> observable, TreeItem<com.mediamarktsaturn.idm.tools.Element> selected)
   {

      String xmlTags[] = new String[] { "TYPE", "TODB", "DESCRIPTION", "SQLUPDATE", "SCRIPTNEXT", "FROMSQL", "ENTRYSCRIPT", "PTERMINATE", "PINITIALIZE", "FROMDB" };
      String S_search = searchText.getText();
      infoBox.clear();
      resultPane.getChildren().clear();

      if (selected == null || selected.getValue() == null) {
         return;
      }
      infoBox.setText(selected.getValue().toString());
      currentSelectedElement = selected.getValue();
      if (autoCopyID) {
         copyId();
      }
      if (selected == null || selected.getValue() == null || selected.getValue().getData() == null) {
         return;
      }
      if (currentSelectedElement.getCheckInfo() != null) {
         resultText.getChildren().add(new Text("Check Results:\r\n" + currentSelectedElement.getCheckInfo() + "\r\nCode:\r\n"));
      }

      CPane resultXMLPane = new CPane();
      FX.style(resultXMLPane, EDITOR);

      ArrayList<Object> fullTextObject = new ArrayList<Object>();
      model = new SimpleStyledTextModel();
      
      HashMap<String, Object> sequenceMap = new HashMap<String, Object>();
      ArrayList<String> sequenceMapArray = new ArrayList<String>();
      HashMap<String, String> sequenceMapEnableArray = new HashMap<String, String>();

      if (showAllwaysXML == true && currentSelectedElement.getType().equals("JOB")) {
         // parse job definition for
         try {
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            InputSource is = new InputSource(new StringReader(currentSelectedElement.getData()));
            Document doc = dBuilder.parse(is);
            doc.getDocumentElement().normalize();

            // Get all the mxjob elements and then loop over them
            addAttributeValue(Color.GREEN, fullTextObject, "=== JOB ====", "============================","ATTA",Color.GREEN);
            NodeList mxjob = doc.getElementsByTagName("mx:Job");
            addAttributeValue(Color.GREEN, fullTextObject, "NAME", selected.getValue().getName());

            addAttributeValue(Color.GREEN, fullTextObject, "GUID", selected.getValue().getGuid() );

            NodeList mxjobEntries = mxjob.item(0).getChildNodes();
            for (int j = 0; j < mxjobEntries.getLength(); j++) {
               // Traverse down the mxjob node
               // mx:Pass
               // TYPE
               // DESCRIPTION
               // TODB
               Node pass = mxjobEntries.item(j);
               if (pass.getNodeName().equals("mx:Sequence")) {
                  // get sequence of passes and store it to a hashmap
                  NodeList sequences = pass.getChildNodes();
                  for (int i = 0; i < sequences.getLength(); i++) {
                     Node current = sequences.item(i);
                     // Only want stuff from ELEMENT nodes
                     if (current.getNodeType() == Node.ELEMENT_NODE) {
                        if (current.getNodeName().equals("mx:Step")) {
                           Node step = current;
                           if (step.getNodeType() == Node.ELEMENT_NODE) {
                              // mx:Class -> create two column table for this
                              // mx:attr name
                              // mx:value
                              sequenceMapArray.add(((String) ((Element) step).getAttribute("Key")));
                              sequenceMapEnableArray.put(((String) ((Element) step).getAttribute("Key")),((String) ((Element) step).getAttribute("Enabled")));
                           }
                        }
                     }
                  }
               }
               if (pass.getNodeName().equals("mx:Functions")) {
                  // Get all children nodes from pass
                  NodeList functions = pass.getChildNodes();
                  addAttributeValue(Color.GREEN, fullTextObject, "=== SCRIPT =", "============================","ATTA",Color.GREEN);
                  for (int i = 0; i < functions.getLength(); i++) {
                     Node current = functions.item(i);
                     // Only want stuff from ELEMENT nodes
                     if (current.getNodeType() == Node.ELEMENT_NODE) {
                        if (current.getNodeName().equals("mx:Function")) {
                           Node destLine = current;
                           if (destLine.getNodeType() == Node.ELEMENT_NODE) {
                              // mx:Class -> create two column table for this
                              // mx:attr name
                              // mx:value
                              String scriptname = ((String) ((Element) destLine).getAttribute("name"));
                              String globalScript = ((String) ((Element) destLine).getAttribute("GlobalScript"));
                              String externalScript = ((String) ((Element) destLine).getAttribute("ExternalScript"));

                              if (externalScript != null && externalScript != "") { // external
                                                                                    // script
                                 addAttributeValue(Color.BLUE, fullTextObject, scriptname, "External Script: " + externalScript, S_search);
                              } else if (globalScript != null && globalScript != "") {
                                 addAttributeValue(Color.BLUE, fullTextObject, scriptname, "<Package Script>", S_search);
                              } else {
                                 addAttributeValue(Color.BLUE, fullTextObject, scriptname, ((Element) destLine).getElementsByTagName("mx:Code").item(0).getTextContent(), S_search);
                              }
                           }
                        }
                     }
                  }
               }
            }
            for (int j = 0; j < mxjobEntries.getLength(); j++) {
               Node pass = mxjobEntries.item(j);
               if (pass.getNodeName().equals("mx:Pass")) {
                  // Get all children nodes from pass
                  NodeList passAttributes = pass.getChildNodes();
                  ArrayList<Object> passTextObject = new ArrayList<Object>();
                  String passname = ((String) ((Element) pass).getAttribute("name"));

                  
                  addAttributeValue(Color.GREEN, passTextObject, "=== PASS ===", "============================","ATTA",Color.GREEN);
                  addAttributeValue(Color.GREEN, passTextObject, "ENABLE", sequenceMapEnableArray.get(passname),"ATTA",Color.DARKMAGENTA);
                  for (int i = 0; i < passAttributes.getLength(); i++) {
                     Node current = passAttributes.item(i);
                     // Only want stuff from ELEMENT nodes
                     if (current.getNodeType() == Node.ELEMENT_NODE) {
                        if (Arrays.asList(xmlTags).contains(current.getNodeName())) {
                           if ( current.getNodeName().equalsIgnoreCase("DESCRIPTION") ) {
                              addAttributeValue(Color.DARKMAGENTA, passTextObject, current.getNodeName(), current.getTextContent(), S_search, Color.DARKMAGENTA);
                           } else {
                              addAttributeValue(Color.GREEN, passTextObject, current.getNodeName(), current.getTextContent(), S_search);
                           }
                        }
                        if (current.getNodeName().equals("mx:Class")) {
                           NodeList destinationLines = current.getChildNodes();
                           for (int k = 0; k < destinationLines.getLength(); k++) {
                              Node destLine = destinationLines.item(k);
                              if (destLine.getNodeType() == Node.ELEMENT_NODE) {
                                 // mx:Class -> create two column table for this
                                 // mx:attr name
                                 // mx:value
                                 String attrname = ((String) ((Element) destLine).getAttribute("name"));
                                 if (!attrname.equals("DeltaKey")) {
                                    addAttributeValue(Color.BLUE, passTextObject, attrname, ((Element) destLine).getElementsByTagName("mx:value").item(0).getTextContent(), S_search);
                                 }
                              }
                           }
                        }
                     }
                  }
                  sequenceMap.put(passname, passTextObject);
               }
            }
            for ( int ii = 0; ii < sequenceMapArray.size(); ii++) {
               if (sequenceMap.containsKey(sequenceMapArray.get(ii))) {
               fullTextObject.addAll((ArrayList<Object>)sequenceMap.get(sequenceMapArray.get(ii)));
               }
            }
         } catch (Exception e) {
            e.printStackTrace();
         }

      } else { // plain text result
         if (S_search == null || S_search.length() == 0) {
            model.add(null, currentSelectedElement.getData());
         } else {
            fullTextObject = getColorSelectedString(fullTextObject, currentSelectedElement.getData(), S_search);
         }
      }
      Object[] fullTextObjectArray = new Object[fullTextObject.size()];
      fullTextObject.toArray(fullTextObjectArray);
      model.add(fullTextObjectArray);
      FxEditor ed = new FxEditor(model);
      ed.setMultipleSelectionEnabled(true);
      ed.setContentPadding(new Insets(2, 5, 2, 5));
      ed.setShowLineNumbers(false);
      ed.prefHeightProperty().bind(resultPane.heightProperty());
      ed.prefWidthProperty().bind(resultPane.widthProperty());
      ed.setStyle("-fx-font-family: monospace;");
      resultXMLPane.setCenter(ed);
      resultPane.prefHeightProperty().bind(resultBox.heightProperty());
      resultPane.prefWidthProperty().bind(resultBox.widthProperty());
      resultPane.getChildren().add(resultXMLPane);
   }

   private void parseArguments(Map<String, String> args)
   {
      for (Entry<String, String> entry : args.entrySet()) {
         if (entry.getKey().toLowerCase().equalsIgnoreCase("hostname")) {
            connectDBHostname.setText(entry.getValue());
         }
         if (entry.getKey().equalsIgnoreCase("username")) {
            connectDBusername.setText(entry.getValue());
         }
         if (entry.getKey().equalsIgnoreCase("password")) {
            connectDBpassword.setText(entry.getValue());
         }
         if (entry.getKey().equalsIgnoreCase("port")) {
            connectDBPort.setText(entry.getValue());
         }
         if (entry.getKey().equalsIgnoreCase("sid")) {
            connectDBSID.setText(entry.getValue());
         }
         if (entry.getKey().equalsIgnoreCase("debugjobguids")) {
            dbg_guids = entry.getValue();
            S_version += " (with debug mode enabled)";
         }
         if (entry.getKey().equalsIgnoreCase("showXML")) {
            showAllwaysXML = Boolean.parseBoolean(entry.getValue());
         }
         if (entry.getKey().equalsIgnoreCase("autoCopyID")) {
            autoCopyID = Boolean.parseBoolean(entry.getValue());
         }
      }
   }

   /*
    * IdM related functions
    * 
    */
   private boolean loadIdMData()
   {
      if (dataLoaded == true) {
         return (false);
      } else {
         idmSearch = null;
      }
      idmSearch = new Search("jdbc:oracle:thin:@" + connectDBHostname.getText() + ":" + connectDBPort.getText() + ":" + connectDBSID.getText(), connectDBusername.getText(),
            connectDBpassword.getText());
      idmSearch.buidConfigurationTree(dbg_guids);
      packageNames = idmSearch.getPackageNames();
      statusBar.setText("Data loaded. " + S_version);
      dataLoaded = true;
      return (true);
   }

   /*
    * #######################################################################
    * Read Data
    * #######################################################################
    */

}
