// ********************************************************************************
// IdM Search Tool (only IdM 8 is supported, tested for oralcle and DB2)
// Version for DSAG members only
// Modified; Steinberg, Ansgar <Ansgar.Steinberg@cellent.de>; 07-2019 supporting other DBs
// ********************************************************************************// 
// **** Legal Disclaimer ***
// The IdM Search Tool is provided by Andreas Zickner "as is" and "with all faults." 
// Andreas Zickner makes no representations or warranties of any kind concerning the 
// safety, suitability, lack of viruses, inaccuracies, typographical errors, or other 
// harmful components of the IdM Search Tool. There are inherent dangers in the use 
// of any software, and you are solely responsible for determining whether the IdM 
// Search Tool is compatible with your equipment and other software installed on your 
// equipment. You are also solely responsible for the protection of your equipment 
// and backup of your data, and Andreas Zickner will not be liable for any damages 
// you may suffer in connection with using, modifying, or distributing the IdM Search Tool.
// ********************************************************************************
package com.mediamarktsaturn.idm.tools;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
// import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
// import java.util.Comparator;
import java.util.List;

import javax.xml.namespace.NamespaceContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class Search
{

   private DatabaseAccess idm = null;
   private String aDbURL = "jdbc:oracle:thin:@localhost:1522:IDM";
   private String aDriverClass = "oracle.jdbc.driver.OracleDriver";
   private String username = "mxmc_oper";
   private String password = "sap123";
   private List<Element> jobFolder;
   private List<Element> jobDefinitions;
   private List<Element> jobFolderTop = new ArrayList<Element>();
   private List<Element> scriptDefinitions;
   private List<Element> taskFolder;
   private List<Element> taskDefinitions;
   private List<Element> taskAccessDefinitions;
   private List<Element> taskAttributeDefinitions;
   private List<Element> taskJobDefinitions;
   private List<Element> constantDefinitions;
   private List<Element> taskFolderTop = new ArrayList<Element>();
   private List<Element> allData = new ArrayList<Element>();

   public Search(String pDbURL, String pusername, String ppassword, String pjdbcDriverClass) {
      aDbURL = pDbURL;
      username = pusername;
      password = ppassword;
      if (pjdbcDriverClass != null) {
         aDriverClass = pjdbcDriverClass;
      }
      try {
         idm = new DatabaseAccess(aDbURL, aDriverClass, username, password);
      } catch (SQLException e) {
         e.printStackTrace();
      }
   }

   public void buidConfigurationTree(String debug)
   {
      try {
         if (debug != null) {
            debug = "'" + debug.replace(",", "','") + "'";
         }
         System.out.println("Load Job Folders");
         jobFolder = idm.getJobFolders("0");
         allData.addAll(jobFolder);
         System.out.println("Load Job Definitions");
         jobDefinitions = idm.getJobDefinitions("0", debug);
         allData.addAll(jobDefinitions);
         for (Element temp : jobFolder) {
            if (temp.getParentid() == -1) {
               jobFolderTop.add(temp);
            } else {
               for (Element temp_parent : jobFolder) {
                  if (temp_parent.getId() == temp.getParentid()) {
                     temp_parent.addChild(temp);
                     temp.setParent(temp_parent);
                  }
               }
            }
            for (Element temp_jobs : jobDefinitions) {
               if (temp.getId() == temp_jobs.getParentid()) {
                  temp.addChild(temp_jobs);
                  temp_jobs.setParent(temp);

               }
            }
         }
         if (debug == null) {
            System.out.println("Load Task Folders");
            taskFolder = idm.getJobFolders("1");
            allData.addAll(taskFolder);
            System.out.println("Load Job Definitions of Task");
            taskJobDefinitions = idm.getJobDefinitions("1", debug);
            allData.addAll(taskJobDefinitions);
            System.out.println("Load Task Definitions");
            taskDefinitions = idm.getTaskDefinitions(debug);
            taskAccessDefinitions = idm.getTaskAccessDefinitions(debug);
            taskDefinitions.addAll(taskAccessDefinitions);
            taskAttributeDefinitions = idm.getTaskAttributesDefinitions(debug);
            taskDefinitions.addAll(taskAttributeDefinitions);
            allData.addAll(taskDefinitions);
            for (Element temp : taskFolder) {
               if (temp.getParentid() == -1) {
                  taskFolderTop.add(temp);
               } else {
                  for (Element temp_parent : taskFolder) {
                     if (temp_parent.getId() == temp.getParentid()) {
                        temp_parent.addChild(temp);
                        temp.setParent(temp_parent);
                     }
                  }
               }
               for (Element temp_tasks : taskDefinitions) {
                  if (temp.getId() == temp_tasks.getParentid()) {
                     temp.addChild(temp_tasks);
                     temp_tasks.setParent(temp);
                  }
               }
            }
            for (Element temp_tasks : taskDefinitions) {
               for (Element temp_tasksChild : taskDefinitions) {
                  if (temp_tasks.getId() == temp_tasksChild.getParentid()) {
                     temp_tasks.addChild(temp_tasksChild);
                     temp_tasksChild.setParent(temp_tasks);
                  }
               }
               for (Element temp_jobs : taskJobDefinitions) {
                  if (temp_tasks.getJobLinkGuid().equalsIgnoreCase(temp_jobs.getJobLinkGuid())) {
                     temp_tasks.addChild(temp_jobs);
                     temp_jobs.setParent(temp_tasks);
                  }
               }
            }
            System.out.println("Load Script Definitions");
            scriptDefinitions = idm.getScriptDefinitions();
            allData.addAll(scriptDefinitions);

            System.out.println("Load Constant Definitions");
            constantDefinitions = idm.getConstantDefinitions();
            allData.addAll(constantDefinitions);
         }
      } catch (SQLException | UnsupportedEncodingException | IllegalBase64Exception e) {
         e.printStackTrace();
      }
      System.out.println("Done Loading");
   }

   public void printTree()
   {
      System.out.println("Task Folders\r\n===================");
      for (Element temp : taskFolderTop) {
         printChild(temp, "");
      }
      System.out.println("\r\nJob Folders\r\n===================");
      for (Element temp : jobFolderTop) {
         printChild(temp, "");
      }
   }

   public void printChild(Element el, String prefix)
   {
      System.out.println(prefix + el.getName() + " (" + el.getId() + ", " + el.getType() + ")");
      for (Element temp : el.getChilds()) {
         printChild(temp, prefix + "  ");
      }
   }

   public List<Element> findElements(String s_search, boolean sensitiv)
   {
      List<Element> foundArray = new ArrayList<Element>();
      for (Element temp : allData) {
         if (temp.searchString(s_search, sensitiv)) {
            foundArray.add(temp);
         }
      }
      return foundArray;
   }

   public List<Element> findConfigInconsistency(String s_search, boolean IdM8Check, boolean checkGlobalConstants, boolean checkScripts) throws ParserConfigurationException, SAXException, IOException
   {
      String[] sA_prefix = { "$FUNCTION.", "<SCRIPTNEXT>", "<PINITIALIZE>", "<PTERMINATE>", "<ENTRYSCRIPT>", "$FORMAT(*", " ", "=" };

      initObjects();
      List<Element> foundArray = new ArrayList<Element>();

      if (IdM8Check == true) {
         for (Element temp : allData) {
            if (s_search.length() > 0 && temp.getPackageName().equalsIgnoreCase(s_search) == false) {
               continue;
            }
            temp.setCheckInfo(null);
            String data = temp.getData();
            if (data != null) {
               boolean add = false;
               if (data.indexOf("%$glb.") > -1) {
                  temp.setCheckInfo("IdM8: Usage of global constant");
                  add = true;
               }
               if (data.toUpperCase().indexOf("MC_REPOSITORY_VARS") > -1) {
                  temp.setCheckInfo("IdM8: Usage of mc_repository_vars");
                  add = true;
               }
               if (add) {
                  foundArray.add(temp);
               }
            }
         }
      }

      List<Element> allJobs = new ArrayList<Element>();
      allJobs.addAll(taskJobDefinitions);
      allJobs.addAll(jobDefinitions);

      for (Element temp : allJobs) {
         if (s_search.length() > 0 && temp.getPackageName().equalsIgnoreCase(s_search) == false) {
            continue;
         }
         DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
         DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
         String xml = temp.getData();
         if (xml == null) {
            // temp.addCheckInfo("Empty job data");
            // foundArray.add(temp);
            continue;
         }
         Document doc = dBuilder.parse(new InputSource(new ByteArrayInputStream(xml.getBytes("utf-8"))));
         doc.getDocumentElement().normalize();
         if (checkJob(doc) == false) {
            temp.addCheckInfo("Invalid job structure");
            foundArray.add(temp);
            System.out.println(" ERR: Invalid job structure in " + temp.toStringLong());
            continue;
         }

         NodeList nList;

         if (checkGlobalConstants == true) {
            nList = doc.getElementsByTagName("mx:Globals");
            for (int i = 0; i < nList.getLength(); i++) {
               Node nNode = nList.item(i);
               if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                  String tagValue = checkTagValues((org.w3c.dom.Element) nNode, "mx:value");
                  if (tagValue == null || tagValue.length() == 0) {
                     temp.addCheckInfo("Empty usage of global references");
                     foundArray.add(temp);
                     i = nList.getLength();
                  }
               }
            }
         }

         if (checkScripts == true) {
            nList = doc.getElementsByTagName("mx:Function");
            boolean foundMissingScriptInJob = false;
            System.out.println("Script check in Job: " + temp.toString());
            for (int i = 0; i < nList.getLength(); i++) {
               String scriptSearchName = nList.item(i).getAttributes().getNamedItem("name").getNodeValue();
               // System.out.println(" Script to check: " + scriptSearchName);
               boolean foundScript = false;
               for (int j = 0; j < sA_prefix.length; j++) {
                  if (xml.contains(sA_prefix[j] + scriptSearchName)) {
                     foundScript = true;
                  }
                  if (foundScript) {
                     // skip the rest in case it is found
                     break;
                  }
               }
               if (foundScript == false) {
                  // search in other linked scripts
                  for (int ii = 0; ii < nList.getLength(); ii++) {
                     String tmpScriptName = nList.item(ii).getAttributes().getNamedItem("name").getNodeValue();
                     if (tmpScriptName != scriptSearchName) {
                        for (Element tempScript : scriptDefinitions) {
                           if (tempScript.getGuid().equals(tmpScriptName)) {
                              if (tempScript.getData().contains(scriptSearchName)) {
                                 foundScript = true;
                                 break;
                              }
                           }
                        }
                        if (foundScript == true) {
                           break;
                        }
                     }
                  }
               }
               if (foundScript == false) {
                  System.out.println("  -> Unused script reference:: " + scriptSearchName);
                  temp.addCheckInfo("Unused script reference: " + scriptSearchName);
                  foundMissingScriptInJob = true;
               }
            }
            if (foundMissingScriptInJob == true) {
               foundArray.add(temp);
            }
         }
      }
      return foundArray;
   }

   private XPath mXPath;

   private void initObjects()
   {
      NamespaceContext ctx = new NamespaceContext() {
         public String getNamespaceURI(String prefix)
         {
            String uri;
            if (prefix.equals("mx")) {
               uri = "http://www.maxware.com/EMS";
            } else {
               uri = "";
            }
            return uri;
         }

         @SuppressWarnings("rawtypes")
         public Iterator getPrefixes(String val)
         {
            return null;
         }

         public String getPrefix(String uri)
         {
            if (uri.equals("http://www.maxware.com/EMS")) {
               return "mx";
            }
            return null;
         }
      };
      this.mXPath = XPathFactory.newInstance().newXPath();
      this.mXPath.setNamespaceContext(ctx);
   }

   private boolean checkJob(Document doc)
   {
      String exp = "//mx:Globals/mx:attr";
      try {
         XPathExpression xPathExpression = this.mXPath.compile(exp);
         if (xPathExpression.evaluate(doc, XPathConstants.NODESET) == null) {
            return false;
         }
      } catch (XPathExpressionException e) {
         e.printStackTrace();
         return false;
      }
      return true;
   }

   private static String checkTagValues(org.w3c.dom.Element eElement, String tag)
   {
      String retval = "NOT FOUND";

      NodeList aList = eElement.getElementsByTagName(tag);
      for (int j = 0; j < aList.getLength(); j++) {
         Node aNode = aList.item(j);
         NodeList nlListChilds = aNode.getChildNodes();
         if (nlListChilds == null) {
            // return "NOT FOUND";
            return null;
         }
         // get value of the node
         Node nValue = (Node) nlListChilds.item(0);
         if (nValue == null) {
            return null;
         } else {
            retval = nValue.getNodeValue();
         }
      }
      return retval;
   }

   public HashMap<String, String> getPackageNames()
   {
      try {
         return idm.getPackageNames();
      } catch (SQLException | UnsupportedEncodingException | IllegalBase64Exception e) {
         e.printStackTrace();
      }
      return null;
   }

}
