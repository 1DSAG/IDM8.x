// ********************************************************************************
// IdM Search Tool (only IdM 8 is supported, tested for oralcle and DB2)
// Version for DSAG members only
// Modified; Steinberg, Ansgar <Ansgar.Steinberg@cellent.de>; 07-2019 supporting other DBs
// ********************************************************************************// 
// **** Legal Disclaimer ***
// The IdM Search Tool is provided by Andreas Zickner "as is" and "with all faults." 
// Andreas Zickner makes no representations or warranties of any kind concerning the 
// safety, suitability, lack of viruses, inaccuracies, typographical errors, or other 
// harmful components of the IdM Search Tool. There are inherent dangers in the use 
// of any software, and you are solely responsible for determining whether the IdM 
// Search Tool is compatible with your equipment and other software installed on your 
// equipment. You are also solely responsible for the protection of your equipment 
// and backup of your data, and Andreas Zickner will not be liable for any damages 
// you may suffer in connection with using, modifying, or distributing the IdM Search Tool.
// ********************************************************************************

package com.mediamarktsaturn.idm.tools;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Element
{
   private String type = "";
   private String taskType = null;
   private String name = "";
   private int id = 0;
   private int parentid = 0;
   private String guid = null;
   private String joblink_guid = "empty";
   private String ownGuid = "empty";
   private Element parent = null;
   private Integer order = null;
   private List<Element> childs = new ArrayList<Element>();
   private String data;
   private String checkInfo = null;
   private String packageName = null;
   private boolean isHistory = false;

   public Element(String atype) {
      this(atype, "", 0, 0, "", 0, null, null);
   }

   public Element(String atype, String aname) {
      this(atype, aname, 0, 0, "", 0, null, null);
   }

   public Element(String atype, String aname, int aid, int aparentid,
         String adata, int aorder, String ajoblink_guid, String aguid) {
      this.type = atype;
      this.name = aname;
      this.id = aid;
      this.parentid = aparentid;
      this.data = adata;
      this.order = new Integer(aorder);
      if (aguid != null) {
         this.guid = aguid;
      }
      if (ajoblink_guid != null) {
         this.joblink_guid = ajoblink_guid;
      }
      this.isHistory = false;
      this.packageName = null;
      if (this.guid == null) {
         this.guid = "GUID:" + this.id + "/" + this.name;
      }
   }

   public Element(String atype, String aname, int aid, int aparentid,
         String adata, int aorder, String ajoblink_guid, String aguid,
         String apackageName) {
      this(atype, aname, aid, aparentid, adata, aorder, ajoblink_guid, aguid);
      this.packageName = apackageName;
   }

   public boolean setParent(Element aparent)
   {
      if (parent == null) {
         parent = aparent;
      }
      aparent.addChild(this);
      return true;
   }

   public Element getParent()
   {
      return parent;
   }

   public void addChild(Element achild)
   {
      childs.add(achild);
   }

   public String getType()
   {
      if (taskType == null) {
         return type;
      } else {
         return type + ":" + taskType;
      }
   }

   public String getAchorType()
   {
      return packageName + "." + type;
   }

   public String getName()
   {
      return name;
   }

   public int getId()
   {
      return id;
   }

   public int getParentid()
   {
      return parentid;
   }

   public String getData()
   {
      return data;
   }

   public String getGuid()
   {
      return guid;
   }

   public String getJobLinkGuid()
   {
      return joblink_guid;
   }

   public void setData(String data)
   {
      this.data = data;
   }

   public List<Element> getChilds()
   {
      Collections.sort(childs, comparator);
      return childs;
   }

   protected Integer getOrder()
   {
      return order;
   }

   Comparator<Element> comparator = new Comparator<Element>() {
      @Override
      public int compare(final Element o1, final Element o2)
      {
         return o1.getOrder().compareTo(o2.getOrder());
      }
   };

   public String toStringLong()
   {
      return type + ": " + getElementId();
   }

   public String toString()
   {
      return getElementId();
   }

   public String getElementId()
   {
      if (id == 0) {
         return name;
      } else {
         return id + "/" + name;
      }
   }

   public boolean searchString(String s_search)
   {
      return (searchString(s_search, false));
   }

   public boolean searchString(String searchString, boolean casesensitive)
   {
      boolean found = false;
      String test1 = getElementId() + guid;
      String test2 = (data == null) ? "" : data;
      if (casesensitive == false) {
         searchString = searchString.toUpperCase();
         test1 = test1.toUpperCase();
         test2 = test2.toUpperCase();
      }
      // search
      if (test1.contains(searchString) || test2.contains(searchString)) {
         found = true;
      }
      return (found);
   }

   public String getOwnGuid()
   {
      return ownGuid;
   }

   public void setOwnGuid(String ownGuid)
   {
      this.ownGuid = ownGuid;
   }

   public String getCheckInfo()
   {
      return checkInfo;
   }

   public void setCheckInfo(String checkInfo)
   {
      this.checkInfo = checkInfo;
      if (this.checkInfo != null) {
         this.checkInfo += "\r\n";
      }
   }

   public void addCheckInfo(String checkInfo)
   {
      if (this.checkInfo != null) {
         this.checkInfo += checkInfo + "\r\n";
      } else {
         this.checkInfo = checkInfo + "\r\n";
      }
   }

   public boolean isHistory()
   {
      return isHistory;
   }

   public void setHistory(boolean isHistory)
   {
      this.isHistory = isHistory;
   }

   public String getPackageName()
   {
      return packageName;
   }

   public String getTaskType()
   {
      return taskType;
   }

   public void setTaskType(String taskType)
   {
      this.taskType = taskType;
   }
}
