// ********************************************************************************
// IdM Search Tool (only IdM 8 is supported, tested for oralcle and DB2, tentative mssqlserver)
// Version for DSAG members only
// Modified; Steinberg, Ansgar <Ansgar.Steinberg@cellent.de>; 07-2019 supporting other DBs
// Modified; zickner; 11-2019 supporting other DBs: sqlserver
// ********************************************************************************// 
// **** Legal Disclaimer ***
// The IdM Search Tool is provided by Andreas Zickner "as is" and "with all faults." 
// Andreas Zickner makes no representations or warranties of any kind concerning the 
// safety, suitability, lack of viruses, inaccuracies, typographical errors, or other 
// harmful components of the IdM Search Tool. There are inherent dangers in the use 
// of any software, and you are solely responsible for determining whether the IdM 
// Search Tool is compatible with your equipment and other software installed on your 
// equipment. You are also solely responsible for the protection of your equipment 
// and backup of your data, and Andreas Zickner will not be liable for any damages 
// you may suffer in connection with using, modifying, or distributing the IdM Search Tool.
// ********************************************************************************
package com.mediamarktsaturn.idm.tools;

import java.io.UnsupportedEncodingException;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DatabaseAccess
{

   private String mDatabaseURL;
   private Connection mConnection;
   private String mLastUsedSQL;
   private int mLastSchemaUpdate = -1;
   private int mdbType = -2;

   public DatabaseAccess(String aDbURL, String aDriverClass, String username, String password) throws SQLException {
      mLastUsedSQL = null;
      mDatabaseURL = aDbURL;
      connect2Db(mDatabaseURL, aDriverClass, username, password);
   }

   private void connect2Db(String aDbURL, String aDriverClass, String username, String password) throws SQLException
   {
      mDatabaseURL = aDbURL;
      registerDrivers(aDriverClass);
      // "jdbc:oracle:thin:@localhost:1521:xe"
      mConnection = DriverManager.getConnection(aDbURL, username, password);
      try {
         if (aDbURL.toUpperCase().startsWith("JDBC:DB2:")) {
            System.out.println("connect2Db: detected DB2 connection -> Enable Autocommit in JDBC connection!");
            mConnection.setAutoCommit(true);
         } else
            mConnection.setAutoCommit(false);
      } catch (SQLException e) {
         e.printStackTrace();
      }
   }

   private boolean registerDrivers(String aDriverClass)
   {
      try {
         Class.forName(aDriverClass);
      } catch (ClassNotFoundException e) {
         e.printStackTrace();
      }
      return true;
   }

   public boolean isIdM8()
   {
      if (getLatestSchemaUpdate() < 1500) {
         return false;
      }
      return true;
   }

   public int getLatestSchemaUpdate()
   {
      if (mLastSchemaUpdate < 0) {
         int lastSchemaUpdate = -2;
         try {
            mLastUsedSQL = "SELECT MAX(versionnum) FROM mc_dbschema";
            Statement statement = mConnection.createStatement();
            ResultSet rs = statement.executeQuery(mLastUsedSQL);
            do {
               if (!rs.next())
                  break;
               lastSchemaUpdate = rs.getInt(1);
               if (rs.wasNull())
                  lastSchemaUpdate = -1;
            } while (true);
            rs.close();
            statement.close();
         } catch (Exception e) {
            lastSchemaUpdate = -1;
         }
         mLastSchemaUpdate = lastSchemaUpdate;
      }
      return mLastSchemaUpdate;
   }

   public int getDBType()
   {
      if (mdbType < 0) {
         int lastmdbType = -2;
         try {
            mLastUsedSQL = "SELECT infovalue FROM mc_dbinfo where infoname = 'TYPENUM'";
            Statement statement = mConnection.createStatement();
            ResultSet rs = statement.executeQuery(mLastUsedSQL);
            do {
               if (!rs.next())
                  break;
               lastmdbType = rs.getInt(1);
               if (rs.wasNull())
                  lastmdbType = -1;
            } while (true);
            rs.close();
            statement.close();
         } catch (Exception e) {
            lastmdbType = -1;
         }
         mdbType = lastmdbType;
      }
      return mdbType;
   }

   private String getLongValueSrc(ResultSet aResultSet, int aIndex) throws SQLException, UnsupportedEncodingException, IllegalBase64Exception
   {
      String result = null;
      ResultSetMetaData metadata = aResultSet.getMetaData();
      if (metadata.getColumnType(aIndex) == 2005) {
         Clob job = aResultSet.getClob(aIndex);
         Long l = new Long(job.length());
         result = job.getSubString(1L, l.intValue());
      } else {
         byte bb[] = null;
         if (metadata.getColumnType(aIndex) == 2004) {
            Blob job = aResultSet.getBlob(aIndex);
            Long l = new Long(job.length());
            bb = job.getBytes(1L, l.intValue());
         } else {
            try {
               result = aResultSet.getString(aIndex);
            } catch (Exception e) {
               result = null;
               bb = null;
            }
         }
         if (bb != null && bb.length > 20)
            if (bb[1] == 0 && bb[3] == 0 && bb[5] == 0)
               result = new String(bb, "UTF-16LE");
            else if (bb[0] == 0 && bb[2] == 0 && bb[4] == 0)
               result = new String(bb, "UTF-16BE");
            else
               result = new String(bb);
      }
      return result;
   }

   private String convertB64(String aInput) throws IllegalBase64Exception, UnsupportedEncodingException
   {
      if (aInput != null && aInput.substring(0, 5).equalsIgnoreCase("{B64}")) {
         String sTemp = aInput.substring(5);
         byte bTemp[] = Base64.decode(sTemp);
         return (new String(bTemp, "UTF-8"));
      }
      return (aInput);
   }

   public List<Element> getJobFolders(String amode) throws SQLException
   {
      String folderType = "JOBFOLDER";
      /*
       * if (getLatestSchemaUpdate() < 1500) {
       * mLastUsedSQL =
       * "select group_name, group_id, NVL(parent_group,-1) parent_group, GROUPGUID, 'idm72' as PACKAGENAME from mc_group where provision_group = "
       * + amode
       * + " order by parent_group, group_name";
       * } else {
       * mLastUsedSQL =
       * "select group_name, group_id, NVL(parent_group,-1) parent_group, GROUPGUID, "
       * +
       * "(select p.mcqualifiedname from mc_package p where p.mcpackageid = j.mcpackageid ) PACKAGENAME "
       * + " from mc_group j where provision_group = " + amode +
       * " order by parent_group, group_name";
       * }
       * 
       */
      if (getLatestSchemaUpdate() < 1500) {
         mLastUsedSQL = "select group_name, group_id, COALESCE(parent_group,-1) parent_group, GROUPGUID, 'idm72' as PACKAGENAME from mc_group where provision_group = " + amode
               + " order by parent_group, group_name";
      } else {
         mLastUsedSQL = "select group_name, group_id, COALESCE(parent_group,-1) parent_group, GROUPGUID, "
               + "(select p.mcqualifiedname from mc_package p where p.mcpackageid = j.mcpackageid ) PACKAGENAME " + " from mc_group j where provision_group = " + amode
               + " order by parent_group, group_name";
      }
      if (amode == "1") {
         folderType = "TASKFOLDER";
      }
      List<Element> a_elem = new ArrayList<Element>();
      try {
         PreparedStatement statement = mConnection.prepareStatement(mLastUsedSQL);
         Element elem = null;
         ResultSet rs = null;
         int i = 0;
         for (rs = statement.executeQuery(); rs.next(); a_elem.add(elem), i++) {
            elem = new Element(folderType, rs.getString(1), rs.getInt(2), rs.getInt(3), rs.getString(1), i, rs.getString(4), rs.getString(4), rs.getString(5));
         }
         rs.close();
         statement.close();
      } catch (Exception e) {
         System.out.println("\r\nException: " + e.toString() + "\r\nQuery: " + mLastUsedSQL);
         return null;
      }
      return a_elem;
   }

   public List<Element> getJobDefinitions(String amode, String debug_guids) throws SQLException, UnsupportedEncodingException, IllegalBase64Exception
   {
      if (getLatestSchemaUpdate() < 1500) {
         mLastUsedSQL = "SELECT JobDefinition,Name,JobId,Group_id,SharedMaster,Repository,JOBGUID, 'idm72' as PACKAGENAME FROM mc_jobs where provision = " + amode;
      } else {
         mLastUsedSQL = "SELECT JobDefinition,Name,JobId,Group_id,SharedMaster,Repository,JOBGUID, " + "(select p.mcqualifiedname from mc_package p where p.mcpackageid = j.mcpackageid ) PACKAGENAME "
               + "FROM mc_jobs j where provision = " + amode + " and mcobsoletedtime is null and jobdefinition is not null";
      }
      if (debug_guids != null) {
         mLastUsedSQL += " and JOBGUID in (" + debug_guids + ")";
      }
      List<Element> a_elem = new ArrayList<Element>();
      try {
         PreparedStatement statement = mConnection.prepareStatement(mLastUsedSQL);
         Element elem = null;
         ResultSet rs = null;
         int i = 10000;
         for (rs = statement.executeQuery(); rs.next(); a_elem.add(elem), i++) {
            String srcDefinition = getLongValueSrc(rs, 1);
            String jobDefinition = convertB64(srcDefinition);
            elem = new Element("JOB", rs.getString(2), rs.getInt(3), rs.getInt(4), jobDefinition, i, rs.getString(7), rs.getString(7), rs.getString(8));
         }
         rs.close();
         statement.close();
      } catch (Exception e) {
         System.out.println("\r\nException: " + e.toString() + "\r\nQuery: " + mLastUsedSQL);
         return null;
      }
      return a_elem;
   }

   public List<Element> getTaskDefinitions(String debug_guids) throws SQLException
   {
      if (getLatestSchemaUpdate() < 1500) {
         mLastUsedSQL = "select lnk.taskref PARENT_ID,lnk.tasklnk TASK_ID," + "t.taskname TASK_NAME," + "t.actiontype TASK_TYPE," + "t.boolsql TASK_BOOLSQL," + "t.jobguid TASK_JOBGUID,"
               + "lnk.childgroup, lnk.childorder, " + "t.taskguid TASK_GUID," + "'idm72' as PACKAGENAME " + "from mxp_tasklnk lnk " + "inner join mxp_tasks t on t.taskid = lnk.tasklnk ";
         if (debug_guids != null) {
            mLastUsedSQL += " where (select taskguid from mxp_tasks where taskid = tasklnk) in (" + debug_guids + ")";
         }
         mLastUsedSQL += " union all "
               + "select  taskgroup, taskid, taskname, actiontype,boolsql,jobguid,'0', WFDISPLAYORDER, taskguid, 'idm72' as PACKAGENAME from mxp_tasks where taskgroup is not null";
         if (debug_guids != null) {
            mLastUsedSQL += " and taskguid in (" + debug_guids + ")";
         }
      } else {
         mLastUsedSQL = "select lnk.taskref PARENT_ID,lnk.tasklnk TASK_ID," + "t.taskname TASK_NAME," + "t.actiontype TASK_TYPE," + "t.boolsql TASK_BOOLSQL," + "t.jobguid TASK_JOBGUID,"
               + "lnk.childgroup, lnk.childorder, " + "t.taskguid TASK_GUID, " + "(select p.mcqualifiedname from mc_package p where p.mcpackageid = t.mcpackageid ) PACKAGENAME "
               + "from mxp_tasklnk lnk " + "inner join mxp_tasks t on t.taskid = lnk.tasklnk and t.MCOBSOLETEDGUID is null ";
         if (debug_guids != null) {
            mLastUsedSQL += " where (select taskguid from mxp_tasks where taskid = tasklnk) in (" + debug_guids + ")";
         }
         mLastUsedSQL += " union all " + "select  taskgroup, taskid, taskname, actiontype,boolsql, jobguid,'0', WFDISPLAYORDER, taskguid, "
               + "(select p.mcqualifiedname from mc_package p where p.mcpackageid = t.mcpackageid ) PACKAGENAME " + "from mxp_tasks t where taskgroup is not null and MCOBSOLETEDGUID is null ";
         if (debug_guids != null) {
            mLastUsedSQL += " and taskguid in (" + debug_guids + ")";
         }
      }
      List<Element> a_elem = new ArrayList<Element>();
      try {
         PreparedStatement statement = mConnection.prepareStatement(mLastUsedSQL);
         Element elem = null;
         ResultSet rs = null;
         for (rs = statement.executeQuery(); rs.next(); a_elem.add(elem)) {
            elem = new Element("TASK", rs.getString(3), rs.getInt(2), rs.getInt(1), rs.getString(5), rs.getInt(8), rs.getString(6), rs.getString(9), rs.getString(10));
            switch (rs.getInt(4)) {
            case -5:
               elem.setTaskType("APPROVAL");
               break;
            case -4:
               elem.setTaskType("SWITCH");
               break;
            case -3:
               elem.setTaskType("CONDITIONAL");
               break;
            }
            if (rs.getString(6) != null) {
               elem.setTaskType("JOBTASK");
            }
         }
         rs.close();
         statement.close();
      } catch (Exception e) {
         System.out.println("\r\nException: " + e.toString() + "\r\nQuery: " + mLastUsedSQL);
         return null;
      }
      return a_elem;
   }

   public List<Element> getTaskAccessDefinitions(String debug_guids) throws SQLException
   {
      if (getLatestSchemaUpdate() < 1500) {
         mLastUsedSQL = "select ta.taskid, t.taskguid, 'Task Access: '||t.taskname, 'Task Access: SQL: '||COALESCE(SQLSCRIPT,'-no query-')||', TargetSQL: '||COALESCE(TARGETSQLSCRIPT,'-no query-'), "
               + "'idm72' as PACKAGENAME,rownum from mxp_taskaccess  ta " + "inner join mxp_tasks t on t.taskid = ta.taskid " + "where (SQLSCRIPT is not null or TARGETSQLSCRIPT is not null)";
      } else {
         mLastUsedSQL = "select ta.taskid, t.taskguid, CONCAT('Task Access: ',t.taskname), CONCAT(CONCAT(CONCAT('Task Access: SQL: ',COALESCE(SQLSCRIPT,'-no query-')),', TargetSQL: '),COALESCE(TARGETSQLSCRIPT,'-no query-')),"
               + "(select p.mcqualifiedname from mc_package p where p.mcpackageid = t.mcpackageid ) PACKAGENAME, rownum " + " from mxp_taskaccess  ta "
               + "inner join mxp_tasks t on t.taskid = ta.taskid and t.MCOBSOLETEDGUID is null " + "where (SQLSCRIPT is not null or TARGETSQLSCRIPT is not null)";

      }
      if (debug_guids != null) {
         mLastUsedSQL += " and t.taskguid in (" + debug_guids + ")";
      }
      List<Element> a_elem = new ArrayList<Element>();
      try {
         PreparedStatement statement = mConnection.prepareStatement(mLastUsedSQL);
         Element elem = null;
         ResultSet rs = null;
         for (rs = statement.executeQuery(); rs.next(); a_elem.add(elem)) {
            elem = new Element("TASKACCESS", rs.getString(3), rs.getInt(1), rs.getInt(1), rs.getString(4), 0, rs.getString(2), rs.getString(2) + ":" + rs.getInt(6), rs.getString(5));
         }
         rs.close();
         statement.close();
      } catch (Exception e) {
         System.out.println("\r\nException: " + e.toString() + "\r\nQuery: " + mLastUsedSQL);
         return null;
      }
      return a_elem;
   }

   public List<Element> getTaskAttributesDefinitions(String debug_guids) throws SQLException
   {
      if (getLatestSchemaUpdate() < 1500) {
         mLastUsedSQL = "select ta.taskid, t.taskguid, (select attrname from mxi_attributes i where i.attr_id = ta.attr_id)||' ('||t.taskname||')',  "
               + "'Task Attribute SQL for '||(select attrname from mxi_attributes i where i.attr_id = ta.attr_id)||': '||ta.sqlvalues, 'idm72' as PACKAGENAME, ta.display_order "
               + "from MXI_TASKATTRIBUTES ta " + "inner join mxp_tasks t on t.taskid = ta.taskid " + "where sqlvalues is not null";
      } else {
         mLastUsedSQL = "select ta.taskid, t.taskguid, CONCAT(CONCAT(CONCAT((select attrname from mxi_attributes i where i.attr_id = ta.attr_id),' ('),t.taskname),')') , "
               + "CONCAT(CONCAT(CONCAT('Task Attribute SQL for ',(select attrname from mxi_attributes i where i.attr_id = ta.attr_id)),': '),ta.sqlvalues),  "
               + "(select p.mcqualifiedname from mc_package p where p.mcpackageid = t.mcpackageid ) PACKAGENAME, ta.display_order " + "from MXI_TASKATTRIBUTES ta "
               + "inner join mxp_tasks t on t.taskid = ta.taskid and t.MCOBSOLETEDGUID is null " + "where sqlvalues is not null";
      }
      if (debug_guids != null) {
         mLastUsedSQL += " and t.taskguid in (" + debug_guids + ")";
      }
      List<Element> a_elem = new ArrayList<Element>();
      try {
         PreparedStatement statement = mConnection.prepareStatement(mLastUsedSQL);
         Element elem = null;
         ResultSet rs = null;
         for (rs = statement.executeQuery(); rs.next(); a_elem.add(elem)) {
            elem = new Element("TASKATTRIBUTE", rs.getString(3), 9000000 + rs.getInt(1), rs.getInt(1), rs.getString(4), 0, rs.getString(2), rs.getString(2) + ":ATTRIBUTE:" + rs.getInt(6),
                  rs.getString(5));
         }
         rs.close();
         statement.close();
      } catch (Exception e) {
         System.out.println("\r\nException: " + e.toString() + "\r\nQuery: " + mLastUsedSQL);
         return null;
      }
      return a_elem;
   }

   public List<Element> getScriptDefinitions() throws SQLException, UnsupportedEncodingException, IllegalBase64Exception
   {
      if (getLatestSchemaUpdate() < 1500) {
         mLastUsedSQL = "SELECT ScriptId,ScriptName,ScriptLanguage,ScriptDefinition,'idm72' as PACKAGENAME FROM mc_global_scripts";
      } else {
         mLastUsedSQL = "SELECT mcScriptId,mcScriptName,mcScriptLanguage,mcScriptDefinition," + "(select p.mcqualifiedname from mc_package p where p.mcpackageid = s.mcpackageid ) PACKAGENAME,"
               + " mcEnabled,mcProtected,mcisobsoleted FROM mc_package_scripts s where mcisobsoleted = 0";
      }
      List<Element> a_elem = new ArrayList<Element>();
      try {
         PreparedStatement statement = mConnection.prepareStatement(mLastUsedSQL);
         Element elem = null;
         ResultSet rs = null;
         int i = 10000;
         for (rs = statement.executeQuery(); rs.next(); a_elem.add(elem), i++) {
            String src = getLongValueSrc(rs, 4);
            String definition = convertB64(src);
            elem = new Element("SCRIPT", rs.getString(2), rs.getInt(1), 0, definition, i, rs.getString(2), rs.getString(2), rs.getString(5));
         }
         rs.close();
         statement.close();
      } catch (Exception e) {
         System.out.println("\r\nException: " + e.toString() + "\r\nQuery: " + mLastUsedSQL);
         return null;
      }
      return a_elem;
   }

   public List<Element> getConstantDefinitions() throws SQLException, UnsupportedEncodingException, IllegalBase64Exception
   {
      if (getLatestSchemaUpdate() < 1500) {
         mLastUsedSQL = "SELECT varname,varvalue,vardescription,'idm72' as PACKAGENAME FROM mc_global_variables";
      } else {
         mLastUsedSQL = "SELECT varname,varvalue,vardescription," + "(select p.mcqualifiedname from mc_package p where p.mcpackageid = s.mcpackageid ) PACKAGENAME " + " FROM mc_package_variables s ";
      }
      List<Element> a_elem = new ArrayList<Element>();
      try {
         PreparedStatement statement = mConnection.prepareStatement(mLastUsedSQL);
         Element elem = null;
         ResultSet rs = null;
         int i = 10000;
         for (rs = statement.executeQuery(); rs.next(); a_elem.add(elem), i++) {
            elem = new Element("CONSTANT", rs.getString(1), 0, 0, rs.getString(2), i, "", rs.getString(1), rs.getString(4));
         }
         rs.close();
         statement.close();
      } catch (Exception e) {
         System.out.println("\r\nException: " + e.toString() + "\r\nQuery: " + mLastUsedSQL);
         return null;
      }
      return a_elem;
   }

   public HashMap<String, String> getPackageNames() throws SQLException, UnsupportedEncodingException, IllegalBase64Exception
   {
      HashMap<String, String> packageNames = null;
      packageNames = new HashMap<String, String>();

      if (getLatestSchemaUpdate() < 1500) {
         packageNames.put("idm72", "0");
      } else {
         mLastUsedSQL = "SELECT mcqualifiedname, to_char(mcpackageid) from mc_package";
         try {
            PreparedStatement statement = mConnection.prepareStatement(mLastUsedSQL);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
               packageNames.put(rs.getString(1), rs.getString(2));
            }
            rs.close();
            statement.close();
         } catch (Exception e) {
            System.out.println("\r\nException: " + e.toString() + "\r\nQuery: " + mLastUsedSQL);
            return null;
         }
      }
      return packageNames;
   }

}
