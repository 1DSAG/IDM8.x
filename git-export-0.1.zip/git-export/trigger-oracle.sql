-- ****************************************************************************************************
-- IdM GIT integraion (only IdM 8 is supported, tested for oracle on windows runtime)
-- Version for DSAG members only
-- ****************************************************************************************************
-- **** Legal Disclaimer ***
-- The IdM GIT is provided by Dirk Rossmann and Andreas Zickner "as is" and "with all faults." 
-- Dirk Rossmann and Andreas Zickner make no representations or warranties of any kind concerning the 
-- safety, suitability, lack of viruses, inaccuracies, typographical errors, or other 
-- harmful components of the IdM Search Tool. There are inherent dangers in the use 
-- of any software, and you are solely responsible for determining whether the IdM 
-- Search Tool is compatible with your equipment and other software installed on your 
-- equipment. You are also solely responsible for the protection of your equipment 
-- and backup of your data, and Dirk Rossmann and Andreas Zickner will not be liable for any damages 
-- you may suffer in connection with using, modifying, or distributing the IdM GIT integraion.
-- ****************************************************************************************************
create or replace TRIGGER MS_PACKAGE_CHECKIN
AFTER INSERT OR UPDATE OF MCLASTMODIFIED ON mc_package
for each row
DECLARE
  nJobId number;

BEGIN
  begin
    select jobid into nJobId from mc_jobs where jobguid = '27730B88-CE3F-40CE-837A-69812A4FB6AD';  -- job Export Package
    exception when no_data_found then
      return;
  end;
  
  mc_job_run_now_noreturn(nJobId);
END;